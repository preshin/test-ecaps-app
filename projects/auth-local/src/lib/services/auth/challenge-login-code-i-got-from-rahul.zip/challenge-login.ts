import { Buffer } from 'buffer';
import * as readline from "readline"
import * as rp from "request-promise";
import * as crypto from "crypto"
import * as util from "util"

const pbkdf2 = util.promisify(crypto.pbkdf2);

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question('Please enter base url(ex-https://api-stage.paysack.com/demo):', (url) => {

    url = url || "https://api-stage.paysack.com/demo";


    rl.question('Please enter username:', (username) => {
        url = url + "/v2/session/challenge/" + username;

        rl.question('Please enter password:', async (pwd) => {
            let session: any;
            try {
                session = await rp({ uri: `${url}`, method: "GET", headers: {}, json: true });
            } catch (e) {
                console.log(e);
                process.exit(1);
            }
            let secret = session.details.pow_secret;
            let salt = Buffer.from(session.details.pow_salt, 'hex');
            let prefix = session.details.pow_hash_prefix;
            let key = await guessKey(secret, salt, prefix, session.details.pow_rounds, session.details.key_length);
            let iv = crypto.randomBytes(16);
            let encryptedPass = await encryptPassword(pwd, key, iv);
            let body = {
                refNo: iv.toString('hex'),
                id: session._id,
                password: encryptedPass
            }

            let tokenResponse: any = await rp({
                uri: `${url}`,
                method: "POST",
                headers: {},
                json: true,
                body: body
            });
            console.log('');
            console.log('token', tokenResponse);

            rl.close();
        });


    })
})

async function encryptPassword(password: string, key: Buffer, iv: Buffer): Promise<string> {
    let cipherName = "aes-256-cbc"

    let cipher = crypto.createCipheriv(cipherName, key, iv);
    cipher.setAutoPadding(true);
    let crypted = cipher.update(password, "utf8", 'hex')
    crypted += cipher.final('hex')
    return crypted;
}

async function guessKey(secretStr: string, salt: Buffer, prefix: string, powRounds: number, keyLen: number): Promise<any> {
    let secret = Number(secretStr);
    let found = false;
    let key;
    let i = 0;
    for (i = 0; i < 200 && found == false; i++) {
        key = await pbkdf2(`${secret + i}`, salt, powRounds, keyLen, 'sha512');
        found = (key.toString('hex').indexOf(prefix) === 0);
    }
    !found && (() => { throw new Error('Max guess limit Reached.Key could not be derived') })();

    return key;
}